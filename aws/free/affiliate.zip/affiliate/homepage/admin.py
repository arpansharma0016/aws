from django.contrib import admin

# Register your models here.
from .models import Newsletter

admin.site.register(Newsletter)
